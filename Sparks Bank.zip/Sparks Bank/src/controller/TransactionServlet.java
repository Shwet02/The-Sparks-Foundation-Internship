package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TransactionServlet
 */
@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransactionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		int account_number=Integer.parseInt(request.getParameter("account_number"));
		int transfer_amount= Integer.parseInt(request.getParameter("amount"));
		System.out.println(name);
		System.out.println(email);
		System.out.println(account_number); 
		System.out.println(transfer_amount);
		int balance_b=0;
		String email_id="";
		
		//database
		try {
			//open connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","root");
			//get data from CustomerDetails table
			String query="select * from CustomerDetails";
			Statement stmt =con.createStatement();
			ResultSet resultset =stmt.executeQuery(query);
			if (resultset.next()) {

				/* int id= resultset.getInt("id");
				String name1 = resultset.getString("name"); 
				int ac = resultset.getInt("account_number"); 
				 
				System.out.println(name1);
				System.out.println(ac); */
				String mail = resultset.getString("email"); 
				System.out.println(mail);  
				int blnc = resultset.getInt("balance");
				System.out.println(blnc);
				balance_b=blnc;
				email_id=mail;
			}
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select *from CustomerDetails where name='"+name+"' and email='"+email+"'");
			if(rs.next()) {
				int customer_balance = rs.getInt("balance");
				out.println("customer_balance: "+customer_balance);
				
				balance_b=balance_b-transfer_amount;
				customer_balance=customer_balance+transfer_amount;
				st.executeUpdate("update CustomerDetails set balance='"+balance_b+"' where email='"+email_id+"'");
				st.executeUpdate("update CustomerDetails set balance='"+customer_balance+"' where email='"+email+"'");
				
				   out.println("Transaction Successful!!!");
				   response.sendRedirect("Customers.jsp");  
				   System.out.println("Transaction Successful!!!");
			}
			else {
				out.println("Please enter valid details");
			}
			//close connection
			rs.close();
			st.close();
			con.close();
		
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
